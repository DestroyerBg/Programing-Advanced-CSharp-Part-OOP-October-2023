﻿using _03.Telephony;
using _03.Telephony.Core;

IEngine engine = new Engine();
engine.Run();