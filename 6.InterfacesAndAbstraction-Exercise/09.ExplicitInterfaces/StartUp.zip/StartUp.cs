﻿using _08.CollectionHierarchy.Core;

IEngine engine = new Engine();
engine.Run();