﻿using _01.Vehicles.Core.Interfaces;

IEngine engine = new Engine();
engine.Run();